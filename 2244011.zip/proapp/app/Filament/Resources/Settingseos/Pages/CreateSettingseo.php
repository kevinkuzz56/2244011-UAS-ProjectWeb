<?php

namespace App\Filament\Resources\Settingseos\Pages;

use App\Filament\Resources\Settingseos\SettingseoResource;
use Filament\Resources\Pages\CreateRecord;

class CreateSettingseo extends CreateRecord
{
    protected static string $resource = SettingseoResource::class;
}
