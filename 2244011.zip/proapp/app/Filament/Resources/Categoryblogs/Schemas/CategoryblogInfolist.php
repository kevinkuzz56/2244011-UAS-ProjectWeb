<?php

namespace App\Filament\Resources\Categoryblogs\Schemas;

use Filament\Schemas\Schema;

class CategoryblogInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                //
            ]);
    }
}
